import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getMessaging, isSupported } from "firebase/messaging";

// ⚠️ Remplacez par la config de VOTRE projet Firebase
// (Console Firebase → Paramètres du projet → Vos applications → config).
// Elle doit être IDENTIQUE à celle de public/firebase-messaging-sw.js.
const firebaseConfig = {
  apiKey: "REMPLACER_apiKey",
  authDomain: "REMPLACER.firebaseapp.com",
  projectId: "REMPLACER",
  storageBucket: "REMPLACER.appspot.com",
  messagingSenderId: "REMPLACER",
  appId: "REMPLACER",
};

// Clé publique VAPID, à récupérer dans Console Firebase → Cloud Messaging →
// "Certificats Web Push" → générer une paire de clés.
export const VAPID_KEY = "REMPLACER_VAPID_KEY";

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

export async function getMessagingIfSupported() {
  try {
    const supported = await isSupported();
    return supported ? getMessaging(app) : null;
  } catch {
    return null;
  }
}
